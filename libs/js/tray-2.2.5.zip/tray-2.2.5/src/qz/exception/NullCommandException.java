package qz.exception;

public class NullCommandException extends javax.print.PrintException {
    public NullCommandException() {
        super();
    }
    public NullCommandException(String msg) {
        super(msg);
    }
}
