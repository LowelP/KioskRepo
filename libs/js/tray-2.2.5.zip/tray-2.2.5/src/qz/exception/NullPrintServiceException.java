package qz.exception;

public class NullPrintServiceException extends javax.print.PrintException {
    public NullPrintServiceException(String msg) {
        super(msg);
    }
}
