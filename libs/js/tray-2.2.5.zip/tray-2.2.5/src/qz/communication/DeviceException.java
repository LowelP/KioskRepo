package qz.communication;

public class DeviceException extends Exception {

    public DeviceException(String message) {
        super(message);
    }

    public DeviceException(Throwable cause) {
        super(cause);
    }

}
