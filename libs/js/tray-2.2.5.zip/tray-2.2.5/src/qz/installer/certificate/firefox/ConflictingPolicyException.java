package qz.installer.certificate.firefox;

class ConflictingPolicyException extends Exception {
    ConflictingPolicyException(String message) {
        super(message);
    }
}
