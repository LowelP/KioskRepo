package qz.ui;

public interface Themeable {
    void refresh();
}
